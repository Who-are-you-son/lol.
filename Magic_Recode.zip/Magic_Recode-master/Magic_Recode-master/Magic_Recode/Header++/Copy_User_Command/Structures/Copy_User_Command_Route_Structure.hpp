#pragma once

struct Route_Structure
{
	float Location[3];
};