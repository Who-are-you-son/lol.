#pragma once

namespace Copy_User_Command
{
	#include "Copy_User_Command_Structures.hpp"

	#include "Copy_User_Command_Variables.hpp"

	#include "Copy_User_Command_Functions.hpp"
};