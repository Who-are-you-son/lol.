#pragma once

namespace Menu_Select
{
	#include "Menu_Select_Variables.hpp"

	#include "Menu_Select_Functions.hpp"
};