#pragma once

__int8 Game_Identifier;

__int8 Freeze_Controlled_Creature;

__int8 User_Commands_Recorder_Record;

__int8 User_Commands_Recorder_Playback;

void* Original_Menu_Select_Caller_Location;