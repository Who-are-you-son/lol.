#pragma once

void Initialize_Menu_Select()
{
	Freeze_Controlled_Creature = 0;

	User_Commands_Recorder_Record = 0;

	User_Commands_Recorder_Playback = 0;
}