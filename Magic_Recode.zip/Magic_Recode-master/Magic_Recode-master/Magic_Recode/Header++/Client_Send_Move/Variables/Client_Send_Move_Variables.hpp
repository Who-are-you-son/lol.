#pragma once

void* Original_Client_Send_Move_Caller_Location;