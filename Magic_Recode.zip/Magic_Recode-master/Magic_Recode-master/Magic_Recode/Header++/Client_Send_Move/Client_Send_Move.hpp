#pragma once

namespace Client_Send_Move
{
	#include "Client_Send_Move_Variables.hpp"

	#include "Client_Send_Move_Functions.hpp"
};