#pragma once

namespace Byte_Manager
{
	#include "Byte_Manager_Functions.hpp"
};