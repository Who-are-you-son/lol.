#pragma once

void Initialize_Chat_Print_Formatted()
{
	Recorder_User_Comamand_Number_History.Initialize();

	Recorder_User_Comamand_Number_History_Number = 0;

	Recorder_User_Comamand_Number_Greatest_History_Number = 0;
}