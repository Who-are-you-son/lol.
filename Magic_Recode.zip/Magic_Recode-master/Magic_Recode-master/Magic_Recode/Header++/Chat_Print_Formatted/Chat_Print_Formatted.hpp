#pragma once

namespace Chat_Print_Formatted
{
	#include "Chat_Print_Formatted_Variables.hpp"

	#include "Chat_Print_Formatted_Functions.hpp"
};