#pragma once

struct Vertex_Structure
{
	float X;

	float Y;

	float Z;

	float Reciprocal_Homogeneous_W;

	unsigned __int32 Color;
};