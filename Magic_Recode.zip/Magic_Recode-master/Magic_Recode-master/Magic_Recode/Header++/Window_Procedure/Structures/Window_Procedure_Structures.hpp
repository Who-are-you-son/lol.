#pragma once

#include "Window_Procedure_Vertex_Structure.hpp"