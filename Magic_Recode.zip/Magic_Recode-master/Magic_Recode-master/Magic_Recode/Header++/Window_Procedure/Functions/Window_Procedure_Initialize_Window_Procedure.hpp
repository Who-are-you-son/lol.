#pragma once

void Initialize_Window_Procedure()
{
	Setting_Up_Keybinds = 0;

	User_Commands_Strafe_Optimizer_Optimize_Bound_To = VK_F1;

	User_Commands_Recorder_Record_Bound_To = VK_F2;

	User_Commands_Recorder_Playback_Bound_To = VK_F3;

	Route_Recorder_Record_Bound_To = VK_F4;

	Visuals_Recorded_Route_Draw = 0;

	Visuals_Recorded_Route_Vertices.Initialize();
}