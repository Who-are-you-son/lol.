#pragma once

namespace Window_Procedure
{
	#include "Window_Procedure_Structures.hpp"

	#include "Window_Procedure_Variables.hpp"

	#include "Window_Procedure_Functions.hpp"
};