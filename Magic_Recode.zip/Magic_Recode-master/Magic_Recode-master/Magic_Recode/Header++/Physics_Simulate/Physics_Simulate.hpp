#pragma once

namespace Physics_Simulate
{
	#include "Physics_Simulate_Variables.hpp"

	#include "Physics_Simulate_Functions.hpp"
};