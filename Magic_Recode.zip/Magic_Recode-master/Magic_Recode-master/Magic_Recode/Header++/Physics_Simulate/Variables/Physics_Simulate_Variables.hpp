#pragma once

void* Original_Physics_Simulate_Caller_Location;