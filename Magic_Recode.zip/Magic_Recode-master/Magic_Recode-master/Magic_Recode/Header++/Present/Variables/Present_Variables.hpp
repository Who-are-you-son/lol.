#pragma once

unsigned __int32 Visuals_Recorded_Route_Step_Length;

void* Original_Present_Caller_Location;