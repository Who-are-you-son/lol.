#pragma once

namespace Present
{
	#include "Present_Variables.hpp"

	#include "Present_Functions.hpp"
};