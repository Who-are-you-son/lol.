#pragma once

void Initialize_Present()
{
	Visuals_Recorded_Route_Step_Length = 1;
}