#pragma once

void Initialize_Controller_Move()
{
	Draw_Graphical_User_Interface = 0;
}