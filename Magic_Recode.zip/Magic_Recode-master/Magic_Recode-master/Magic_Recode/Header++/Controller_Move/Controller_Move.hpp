#pragma once

namespace Controller_Move
{
	#include "Controller_Move_Variables.hpp"

	#include "Controller_Move_Functions.hpp"
};