#pragma once

__int8 Draw_Graphical_User_Interface;

void* Original_Controller_Move_Caller_Location;