#pragma once

namespace Immediate_Mode_Graphical_User_Interface
{
	#include "Immediate_Mode_Graphical_User_Interface_Functions.hpp"
};