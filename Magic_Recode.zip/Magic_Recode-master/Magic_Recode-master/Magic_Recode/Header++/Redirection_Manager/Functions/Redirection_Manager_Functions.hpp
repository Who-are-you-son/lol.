#pragma once

#include "Redirection_Manager_Redirect_Function.hpp"