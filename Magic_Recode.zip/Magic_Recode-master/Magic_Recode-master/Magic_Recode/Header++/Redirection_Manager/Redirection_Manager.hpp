#pragma once

namespace Redirection_Manager
{
	#include "Redirection_Manager_Functions.hpp"
};