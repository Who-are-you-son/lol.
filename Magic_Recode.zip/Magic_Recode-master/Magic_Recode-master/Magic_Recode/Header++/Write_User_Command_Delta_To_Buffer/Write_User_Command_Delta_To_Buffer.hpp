#pragma once

namespace Write_User_Command_Delta_To_Buffer
{
	#include "Write_User_Command_Delta_To_Buffer_Variables.hpp"

	#include "Write_User_Command_Delta_To_Buffer_Functions.hpp"
};